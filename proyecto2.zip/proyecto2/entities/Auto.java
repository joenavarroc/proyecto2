package entities;

import java.text.DecimalFormat;

public class Auto extends Vehiculo{
    private int puertas;
    
    DecimalFormat df= new DecimalFormat("$###,###.00");

    public Auto(String marca, String modelo, int puertas, double precio){
        super(marca,modelo,precio);
        this.puertas = puertas;
    }
    @Override
    public String toString() {
        return "Marca: "+getMarca()+ "// Modelo: " + getModelo()+ " // Puertas: " + puertas + "" + " // Precio: " +  df.format(getPrecio());
    }
}
