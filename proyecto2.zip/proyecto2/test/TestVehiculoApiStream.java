package test;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import entities.Auto;
import entities.Moto;
import entities.Vehiculo;

public class TestVehiculoApiStream {
        private static List<Vehiculo> vehiculos = new ArrayList();

        public static void main(String[] args) {

                ListaVehiculo();

                separador();
                vehiculos.stream().forEach(System.out::println);

                separador();
                precioMaximo();

                precioMinimo();

                contieneLetraY();

                ordenMayorMenor();

                separador();
                ordenNatural();
        }

        private static void ordenNatural() {
                vehiculos
                                .stream()
                                .sorted()
                                .forEach(System.out::println);
        }

        private static void ordenMayorMenor() {
                separador();
                System.out.println("Vehículos ordenados por precio de mayor a menor:");
                vehiculos.stream()
                                .sorted(Comparator.comparingDouble(Vehiculo::getPrecio).reversed())
                                .forEach(vehiculo -> System.out
                                                .println(vehiculo.getMarca() + " " + vehiculo.getModelo()));
        }

        private static void contieneLetraY() {
                vehiculos
                                .stream()
                                .filter(vehiculo -> vehiculo
                                                .getModelo()
                                                .toLowerCase()
                                                .contains("y"))
                                .forEach(vehiculo -> System.out
                                                .println("vehículo que contiene el modelo de la letra 'Y': "
                                                                + vehiculo.getMarca() + " "
                                                                + vehiculo.getModelo() + " "
                                                                + vehiculo.getPreciodf()));
        }

        private static void precioMinimo() {
                double precioMinimo = vehiculos
                                .stream()
                                .min(Comparator.comparingDouble(Vehiculo::getPrecio))
                                .get()
                                .getPrecio();
                vehiculos
                                .stream()
                                .filter(vehiculo -> vehiculo.getPrecio() == precioMinimo)
                                .forEach(vehiculo -> System.out.println("Vehículo más barato: " + vehiculo.getMarca()
                                                + " " + vehiculo.getModelo()));
        }

        private static void precioMaximo() {
                double precioMaximo = vehiculos
                                .stream()
                                .max(Comparator.comparingDouble(Vehiculo::getPrecio))
                                .get()
                                .getPrecio();
                vehiculos
                                .stream()
                                .filter(vehiculo -> vehiculo.getPrecio() == precioMaximo)
                                .forEach(vehiculo -> System.out.println("Vehículo más caro: " + vehiculo.getMarca()
                                                + " " + vehiculo.getModelo()));
        }

        private static void ListaVehiculo() {
                extracted();
        }

        private static void extracted() {
                lista();
        }

        private static void lista() {
                vehiculos.add(new Auto("Peugeot", "206", 4, 200000));
                vehiculos.add(new Moto("Honda", "Titan", "125c", 60000));
                vehiculos.add(new Auto("Peugeot", "208", 5, 250000));
                vehiculos.add(new Moto("Yamaha", "YBR", "160c", 80500.50));
        }

        private static void separador() {
                System.out.println("***********************************************");
        }

}
