package test;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import entities.Auto;
import entities.Moto;
import entities.Vehiculo;

public class TestVehiculoApiStream {
    public static void main(String[] args) {
        List<Vehiculo>vehiculos=new ArrayList();
        vehiculos.add(new Auto("Peugeot","206",4,200000));
        vehiculos.add(new Moto("Honda", "Titan", "125c", 60000));
        vehiculos.add(new Auto("Peugeot","208",5,250000));
        vehiculos.add(new Moto("Yamaha", "YBR", "160c", 80500.50));

        DecimalFormat df= new DecimalFormat("$###,###.00");

        System.out.println("***********************************************");
        vehiculos.stream().forEach(System.out::println);

        System.out.println("***********************************************");
        double precioMaximo=vehiculos
                .stream()
                .max(Comparator.comparingDouble(Vehiculo::getPrecio))
                .get()
                .getPrecio();
        vehiculos
                .stream()
                .filter(vehiculo -> vehiculo.getPrecio()==precioMaximo)
                .forEach(vehiculo -> System.out.println("Vehículo más caro: " + vehiculo.getMarca()+" "+ vehiculo.getModelo()));

                double precioMinimo=vehiculos
                .stream()
                .min(Comparator.comparingDouble(Vehiculo::getPrecio))
                .get()
                .getPrecio();
        vehiculos
                .stream()
                .filter(vehiculo -> vehiculo.getPrecio()==precioMinimo)
                .forEach(vehiculo -> System.out.println("Vehículo más barato: " + vehiculo.getMarca()+" "+ vehiculo.getModelo()));        
        
        vehiculos
                .stream()
                .filter(vehiculo->vehiculo
                                        .getModelo()
                                        .toLowerCase()
                                        .contains("y"))
                .forEach(vehiculo -> System.out.println
                                        ("vehículo que contiene el modelo de la letra 'Y': " 
                                        + vehiculo.getMarca() +" " 
                                        + vehiculo.getModelo() +" "
                                        +df.format(vehiculo.getPrecio())));        
    
        System.out.println("***********************************************");
        System.out.println("Vehículos ordenados por precio de mayor a menor:");
        vehiculos .stream()
                .sorted(Comparator.comparingDouble(Vehiculo::getPrecio).reversed())
                .forEach(vehiculo->System.out.println(vehiculo.getMarca() +" " + vehiculo.getModelo()));   

        System.out.println("***********************************************");
        vehiculos
                .stream()
                .sorted(Comparator.comparing(Vehiculo::getMarca))
                .forEach(System.out::println);
        }
    
}
